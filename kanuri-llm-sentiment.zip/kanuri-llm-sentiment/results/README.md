# results

Place here the metric tables corresponding to Tables II–VI of the paper, plus confusion matrices for every condition.
