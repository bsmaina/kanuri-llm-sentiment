# evaluation

Place here the scripts used in the paper:
- inference (model loading, 4-bit NF4, greedy decoding)
- strict response parser
- metrics (accuracy, macro-F1, per-class scores, confusion matrices)
- paired bootstrap (2,000 resamples), exact McNemar tests and Holm correction
- TF-IDF + logistic regression baselines
