# predictions

Place here one file per model-view-shot-seed condition (24 in total), each with: record ID, raw model generation, parsed label, validity flag, gold label and prompt hash.

Do not include the input text. Raw generations are fine to include: they are model outputs (single labels), not corpus text.
