# error_audit

Place here the 72-item review sample: 12 items from each of six strata (shared errors, Aya-only errors, Qwen3-only errors, negation/contrast cues, items rescued from Kanuri-only zero-shot failure, correct controls).

For now include record ID, stratum, gold label and both models' predictions only. The Kanuri text, English translation and native-speaker assessment fields will be added once the extended corpus is published.
