# prompts

Place here the exact prompt template for each condition: K-0, K-6, E-0, E-6, KE-0, KE-6.
All instructions and demonstrations are delivered in a single user message, formatted with each model's own chat template.

Use placeholders such as `{kanuri_text}`, `{english_text}` and `{demo_1_text}` instead of real example text. The demonstration IDs for each seed are in `demonstrations/`.
