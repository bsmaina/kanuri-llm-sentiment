# data

Place here:
- `test_ids.csv` — the 1,795 frozen test identifiers with gold labels (446 negative, 950 neutral, 399 positive)
- `train_ids.csv` (14,476) and `dev_ids.csv` (1,608) — overlap-screened partitions
- `run_metadata.json` — model checkpoint revision hashes, library versions and SHA-256 checksums of the frozen benchmark

Do **not** add Kanuri text or English translations yet. They will be added once the extended corpus is published.
