# demonstrations

Place here one file per seed (`seed_42.json`, `seed_123.json`, `seed_456.json`), each listing the six training IDs (two per class), their labels and the corresponding prompt hashes. Include IDs only, not the example text.
